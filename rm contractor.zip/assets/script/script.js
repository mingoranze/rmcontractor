function abrirmenu() {
    let nav = document.getElementById('nav');

    if(nav.classList.contains('close-menu') == true) {
        nav.classList.remove('close-menu');
    } else {
        nav.classList.add('close-menu');
    }
}

let modallink = document.getElementById('modal-link');

modallink.addEventListener('click', (e)=>{
    e.preventDefault()
})


